import cv2
import pose_model_class
import resize_shirt

def impose(frame , pose , t_shirt):

    # Scaling image according to pose
    t_shirt = resize_shirt.scale(t_shirt, pose)

    start_y = pose.shoulder[0][1] - 30
    start_x = pose.shoulder[0][0] - 40

    # getting tshirt height and width
    shape = t_shirt.shape
    h = shape[0]
    w = shape[1]

    # getting frame height and width
    input_shape = frame.shape
    input_height = input_shape[0]
    input_width = input_shape[1]

    if(h <= input_height and w <= input_width):
        for i in range(0, h):
            for j in range(0, w):
                r,g,b,a = t_shirt[i][j]
                if(a != 0):
                    x = (i + start_y)
                    y = (j + start_x)
                    if (x >= input_height):
                        x = input_height - 1
                    
                    if(y > input_width):
                        y = input_width - 1

                    frame[x][y][0] = r
                    frame[x][y][1] = g
                    frame[x][y][2] = b
            
        return frame
    else :
        return frame
