import cv2

def scale(tshirt, pose):
    shoulder = pose.shoulder
    waist = pose.waist
    
    width = abs(shoulder[1][0] - shoulder[0][0]) + 80
    height = abs(shoulder[1][1] - waist[1][1]) + 40
    
    # print(height)
    # print(width)

    if(height != 0 and width != 0 and height >= width) :
        tshirt = cv2.resize(tshirt, (width,height))

    return tshirt



