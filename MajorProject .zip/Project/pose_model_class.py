class Pose:
    def __init__(self, points):
        self.shoulder = [points[1],points[0]]
        self.elbow = [points[3],points[2]]
        self.wrist = [points[5],points[4]]
        self.waist = [points[7],points[6]]
    

    def show_points(self):
        print("shoulders :- " + str(self.shoulder))
        print("waist :- " + str(self.waist))
