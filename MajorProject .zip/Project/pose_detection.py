from ultralytics import YOLO
import cv2
import numpy

def detect(frame):

    model = YOLO('Resources/Model/yolov8n-pose.pt')  # loading YOLO V8N model

    # Predicting pose with the model and storing results in result variable
    results = model(frame)
    
    top = []
    for r in results:
            #Only keypoints of the fore arms and waist are sent
            top = numpy.array(r.keypoints.xy[0][5:13].cpu().numpy())
            break
    
    arr = []
    for i in top:
        arr.append([int(i[0]), int(i[1])])
        if(i[0] != 0 and i[1] != 0) :
            cv2.circle(frame, (int(i[0]), int(i[1])), radius=5, color=(255, 255, 0), thickness=-1)

    return [frame , arr]
