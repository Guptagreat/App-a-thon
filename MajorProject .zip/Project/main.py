import cv2
import numpy
import pose_detection
import pose_model_class
import impose_shirt
import select_shirt

#cap = cv2.VideoCapture("Resources/Videos/Test.mp4")
cap = cv2.VideoCapture(0) 
if not cap.isOpened():
 print("Cannot open camera")
 exit()

# cv2.IMREAD_UNCHANGED will be used to also take the alpha channel in the image
t_shirt = [cv2.imread("Resources/Shirts/1.png",cv2.IMREAD_UNCHANGED),
           cv2.imread("Resources/Shirts/2.png",cv2.IMREAD_UNCHANGED),
           cv2.imread("Resources/Shirts/3.png",cv2.IMREAD_UNCHANGED),
           cv2.imread("Resources/Shirts/4.png",cv2.IMREAD_UNCHANGED),
           cv2.imread("Resources/Shirts/5.png",cv2.IMREAD_UNCHANGED)]
current = 0
           
global pose

while (True):
    
    success, frame = cap.read() #Reading the frame from the video
    
    if not success:
        break #if the frame was not loaded end the loop

    livePose = pose_detection.detect(frame)
    
    frame = livePose[0]
    
    keypoints = numpy.array(livePose[1])
    
    if(keypoints.size != 0):
        
            pose = pose_model_class.Pose(keypoints)

            # Tshirt Selection using hand Gesture
            ch= select_shirt.select(pose)
            print("ch = ", ch)
            if(ch != 0):
                if (ch == 1):
                    if (len(t_shirt) >= current+1):
                        current = 0
                    else:
                        current += 1
                    
                if (ch == -1):
                    if (current <= 0):
                        current = len(t_shirt)-1
                    else:
                        current -= 1

            # Super imposing the shirt on the frame
            print("current =", current)
            frame = impose_shirt.impose(frame, pose, t_shirt[current])

    
    cv2.imshow('VirtualTryOn', frame) #Displaying the frames
    
    if cv2.waitKey(1) & 0xFF == ord('q'): #if user presses escape key, end the loop
        break



cap.release()
cv2.destroyAllWindows()

