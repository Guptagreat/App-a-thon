import pose_model_class
import math


def select(pose):
    righthandside = False
    lefthandside = False
    print(pose.shoulder)
    print(pose.wrist)
    print(pose.elbow)
    hl = math.dist(pose.shoulder[0], pose.elbow[0])
    hr = math.dist(pose.shoulder[1], pose.elbow[1])
    print("oooooo")

    if ((pose.wrist[1][0] - pose.shoulder[1][0]) > hr and (pose.wrist[1][1] - pose.shoulder[1][1]) > hr):
        righthandside = True
        print("Right")
    if ((pose.shoulder[0][0] - pose.wrist[0][0]) > hl and (pose.wrist[0][1] - pose.shoulder[0][1]) > hl):
        lefthandside = True
        print("Left")

    if lefthandside and righthandside:
        if ((pose.shoulder[0][0] - pose.wrist[0][0]) > (pose.shoulder[1][0] - pose.wrist[1][0])):
            return -1
        else:
            return 1
    elif righthandside:
        return 1
    elif lefthandside:
        return -1
    else:
        return 0
        
